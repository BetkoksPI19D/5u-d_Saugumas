﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pirma
{
    public partial class Form1 : Form

    {

        private RSACSP rsacsps = new RSACSP();
        private Sender Sender = new Sender();

        public Form1()
        {
            InitializeComponent();
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            Sender.Send(textBox1.Text, rsacsps.HashAndSignBytes(textBox1.Text), rsacsps.test);
        }
    }
}
